#include <iostream>
#include <pigpio.h>
#include <cstring>
#include <thread>
#include <functional>
#include <chrono>
#include <string>
#include <iomanip>
#include <fstream>
#include <vector>
#include <ctime>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <map>
#include "functionsSFT.h"
//for i2cPT
#include <stdio.h> 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>    // read/write usleep
#include <stdlib.h>    // exit function
#include <inttypes.h>  // uint8_t, etc
#include <linux/i2c-dev.h> // I2C bus definitions
#include <sys/ioctl.h>
//for i2cTC
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>

//for ppp send
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>


using namespace std; using namespace chrono;

void logMessageToSyslog(const char* message)
{
    // const char *destinationIpAddress = "10.0.5.2"; // this is the IP we will message too
    // const char* destinationPort = "1514"; //this is the port we will message too (unintegrated)

    setlogmask(LOG_UPTO(LOG_NOTICE));
    // logging locally
    openlog("PPPTest", LOG_CONS | LOG_PID | LOG_NDELAY, LOG_LOCAL5);
    syslog(LOG_NOTICE, message);

    closelog();
}

//SFT: 0x67=TC-01P 0x66=TC-01O 0x65=TC-02O
string i2cReadTC(int i2cAddr, int i2cFd) { //i2cFd= file descriptor

    ioctl(i2cFd, I2C_SLAVE, i2cAddr); //set i2c device at i2cAddress as a slave device

    char config[2] = { 0 }; //clear array with 0s
    config[0] = 0x05; //00000101, select thermocouple sensor config register
    config[1] = 0x22; //command to send to register, set thermocouple type t and filter response n=2
    write(i2cFd, config, 2);

    config[0] = 0x06; //00000110, select device config register 
    config[1] = 0x00; //sensor resolution = 0.0625C, 18 bit resolution, 1 temperature sample, shutdown mode: normal operation
    write(i2cFd, config, 2);

    char reg[1] = { 0 };
    reg[1] = 0x04; //select raw adc data register holding the conversion values 
    write(i2cFd, reg, 1);

    char data[2] = { 0 }; //holds received i2c data

    if (read(i2cFd, data, 2) != 2) { //read i2c device from raw adc data register and place in "data"
        return "errReadDataTC";
    }
    else {
        int low_temp = data[0] & 0x80; //if bit 7 of data[0] & 1, will be 1, else 0. detects whether i2c data is negative or not
        float r;
        if (low_temp) {
            // printf("Negative temp\n");
            r = data[0] * 16 + data[1] / 16 - 4096;
            return to_string(r);
        }
        else {
            // printf("Positive temp\n");
            r = data[0] * 16 + data[1] * 0.0625;
            return to_string(r);
        }
    }
}

string i2cReport(int i2cFd) { //0b1(100)0000 determines a0-a3 readings, 100=a0, 101=a1, 110=a2, 111=a3

    string S6 = i2cReadTC(0x67, i2cFd);
    string S7 = i2cReadTC(0x66, i2cFd);
    string S8 = i2cReadTC(0x65, i2cFd);

    string valAll = "TC-01P=" + S6 + "," + "TC-01O=" + S7 + "," + "TC-02O=" + S8;
    return valAll;
}

//outputs
//defines gpioPin1-10: AV-01P, AV-02P, AV-01N, AV-02N, AV-01O, AV-02O, AV-01F, AV-03P, camStart, camStop
int gpioPin1 = 4; int gpioPin2 = 17; int gpioPin3 = 27; int gpioPin4 = 22; int gpioPin5 = 10; int gpioPin6 = 9; int gpioPin7 = 11; int gpioPin8 = 0; //valves 
int gpioPin9 = 6; int gpioPin10 = 19;

//inputs, IGNstart is output
//defines gpioPin 11-14: camState1, camState2, IGNbw, IGNstart (reading from GS/ignitor during launchpad phase, include in packet)
int gpioPin11 = 26; int gpioPin12 = 18; int gpioPin13 = 16; int gpioPin21 = 12;
//defines gpioPin 14-17: buff22-1, buff22-2, buff20-1, buff20-2 (batteries)
int gpioPin14 = 23; int gpioPin15 = 24; int gpioPin16 = 8; int gpioPin17 = 7;

//outputs
//defines gpioPin 18-20: drogue deployment pin (output), manual abort pin (input), flow control pin (output)
int gpioPin18 = 20; int gpioPin19 = 21; int gpioPin20 = 25;//skip bcm (gpio)5, 1, there is also 12, 16, 20, 21 // need a pin for drogue deployment signal on launch config

void gpioSet(int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    gpioWrite(gpioPin1, v1); gpioWrite(gpioPin2, v2); gpioWrite(gpioPin3, v3); gpioWrite(gpioPin4, v4); gpioWrite(gpioPin5, v5); gpioWrite(gpioPin6, v6); gpioWrite(gpioPin7, v7); gpioWrite(gpioPin8, v8); gpioWrite(gpioPin9, v9); gpioWrite(gpioPin10, v10);
}



int fallbackState1(int v9, int v10) { //when "reset" go to mState0, else stays
    gpioSet(0, 0, 0, 0, 1, 1, 1, 1, v9, v10); //last 4 signals remain the same as entered with, ign set to 0 by GS
    cout << "entering fallBackState1" << endl;

    string input = "";
    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "reset") {
            cout << "reset read" << endl;
            check = 1;
        }

        input = "";

        if (check == 1) {
            break;
        }

        cin.ignore();
    }

    void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    return 1;
}

int fallbackState2(int v9, int v10) { //when "reset" go to mState0, else stays
    gpioSet(0, 0, 0, 0, 1, 1, 1, 0, v9, v10); //last 4 signals remain the same as entered with, ign set to 0 by GS
    cout << "entering fallBackState2" << endl;

    string input = "";
    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "reset") {
            cout << "reset read" << endl;
            check = 1;
        }

        input = "";

        if (check == 1) {
            break;
        }

        cin.ignore();
    }

    void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    return 1;
}

int fallbackState3(int v9, int v10) { //when "reset" go to mState0, else stays
    gpioSet(0, 0, 0, 0, 1, 1, 0, 0, v9, v10); //last 4 signals remain the same as entered with, ign set to 0 by GS
    cout << "entering fallBackState3" << endl;

    string input = "";
    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "reset") {
            cout << "reset read" << endl;
            check = 1;
        }

        input = "";

        if (check == 1) {
            break;
        }

        cin.ignore();
    }

    void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    return 1;
}

int fallbackState4(int v9, int v10) { //when "reset" go to mState0, else stays
    gpioSet(0, 0, 0, 0, 0, 0, 1, 0, v9, v10); //last 4 signals remain the same as entered with, ign set to 0 by GS
    cout << "entering fallBackState4" << endl;

    string input = "";
    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "reset") {
            cout << "reset read" << endl;
            check = 1;
        }

        input = "";

        if (check == 1) {
            break;
        }

        cin.ignore();
    }

    void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    return 1;
}

int fallbackState5(int v9, int v10) { //when "reset" go to mState0, else stays
    gpioSet(0, 0, 0, 0, 0, 0, 0, 1, v9, v10); //last 4 signals remain the same as entered with, ign set to 0 by GS
    cout << "entering fallBackState5" << endl;

    string input = "";
    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "reset") {
            cout << "reset read" << endl;
            check = 1;
        }

        input = "";

        if (check == 1) {
            break;
        }

        cin.ignore();
    }

    void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    return 1;
}

int pauseState(int v9, int v10) { //looks for either "resume" or "abort" 
    cout << "entering pauseState" << endl;

    string input;
    cout << "enter a command:" << endl;
    cin >> input;

    int check = 0;

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if (input == "resume") {
            cout << "resume read" << endl;
            check = 1;
            break;
        }
        if (input == "abort") {
            cout << "abort read" << endl;
            check = 1;
            fallbackState1(v9, v10); //no break, one way
        }
        if (input == "safe1") {
            cout << "safe1 read" << endl;
            check = 1;
            fallbackState2(v9, v10); //no break, one way
        }
        if (input == "safe2") {
            cout << "safe2 read" << endl;
            check = 1;
            fallbackState3(v9, v10); //no break, one way
        }
        if (input == "safe3") {
            cout << "safe3 read" << endl;
            check = 1;
            fallbackState4(v9, v10); //no break, one way
        }
        if (input == "safe4") {
            cout << "safe4 read" << endl;
            check = 1;
            fallbackState5(v9, v10); //no break, one way
        }

        input = "";

        if (check == 1) {
            break;
        }
    }

    cout << "exit pauseState" << endl;
    return 1;
}

//defines gpioPin 14-17: buff22-1, buff22-2, buff20-1, buff20-2 (batteries)
//int gpioPin14 = 23; int gpioPin15 = 24; int gpioPin16 = 8; int gpioPin17 = 7;


int moveState(int state, int v9, int v10) { //looks for either "moves" or "pause"    
    cout << "entering moveState" << endl;
    int check = 0;
    string input = "";

    while (1) { //now stays until "moves" or "pause" reads
        cout << "enter a command:" << endl;
        cin >> input;

        if ((input == "safe3")) { //" || (state == 7 || state == 8 || state == 9) && PT-01P > 425) aka 425psi or 4.356V"
            cout << "safe3 read" << endl;
            fallbackState3(v9, v10);
        }

        if ((state == 3 || state == 6) && (gpioRead(gpioPin14) == 0)) { //BATTERY=1 AT GPIO
            cout << "pause read due to battery1 LOW" << endl;
            pauseState(v9, v10);
        }
        else if ((state == 3 || state == 6) && (gpioRead(gpioPin15) == 0)) {
            cout << "pause read due to battery2 LOW" << endl;
            pauseState(v9, v10);
        }
        else if ((state == 3 || state == 6) && (gpioRead(gpioPin16) == 0)) {
            cout << "pause read due to battery1 DEAD" << endl;
            pauseState(v9, v10);
        }
        else if ((state == 3 || state == 6) && (gpioRead(gpioPin17) == 0)) {
            cout << "pause read due to battery2 DEAD" << endl;
            pauseState(v9, v10);
        }
        else if ((state == 6 || state == 7 || state == 8 || state == 9) && (gpioRead(gpioPin13) == 0)) {
            cout << "pause read due to IGN-01==0" << endl; //aka wire burned up too early
            pauseState(v9, v10);
        }
        else if ((gpioRead(gpioPin14) == 1 || gpioRead(gpioPin15) == 1 || gpioRead(gpioPin16) == 1 || gpioRead(gpioPin17) == 1) && (state >= 12)) {
            cout << "pause read due to a battery being low or read at or after 'open engine fuel valve' state" << endl;
            pauseState(v9, v10);
        }

        if (input == "moves") { //"moves" is automatically null terminated, processFile must be as well
            cout << "moves read" << endl;
            check = 1;
            break;
        }

        if ((input == "pause")) { //if pause is received 
            cout << "pause read" << endl;
            pauseState(v9, v10); //if pause triggers, keep looping, still need "moves" to escape loop
        }

        input = "";

        if (check == 1) {
            break;
        }
    }

    cout << "exit moveState" << endl;
    return 1;
}

void sendData(int serHandle, int i2cFd) {
    ofstream outfile("/home/pi/Desktop/3-15-2024/dataSFT.csv", std::ios::app); // Open the file outside the loop
    if (!outfile.is_open()) {
        cerr << "Error: Unable to open file for writing." << endl;
    }

    while (1) {
        if (gpioPin19 == 1) {
            cout << "manual abort detected" << endl;
            fallbackState1(0, 0);
        }

        time_t current_time = time(NULL); //prep system time string
        if (current_time == ((time_t)-1)) {
            perror("Error getting time");
            continue; // Skip iteration if time retrieval fails
        }
        struct tm* timeinfo = localtime(&current_time);
        char time_string[80];
        strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", timeinfo);

        //pi pulls pin to high, arduino reads pin high and delay, arduino writes, pi confirms theres a terminator bit and if its correct 
        char buffer[256];

        gpioWrite(gpioPin20, 1); //flow control, send signal when ready to receive arduino signal
        usleep(250000);
        int bytes_read = serRead(serHandle, buffer, sizeof(buffer) - 1);
        gpioWrite(gpioPin20, 0);
        string bufferS = string(buffer);

        stringstream dataS; //prep data packet
        dataS << "time(ms):" << time_string << "," << "AV-01P=" << to_string(gpioRead(gpioPin1)) << "," << "AV-02P=" << to_string(gpioRead(gpioPin2)) << "," << "AV-01N=" << to_string(gpioRead(gpioPin3)) << "," << "AV-02N=" << to_string(gpioRead(gpioPin4)) << "," << "AV-01O=" << to_string(gpioRead(gpioPin5)) << "," << "AV-02O=" << to_string(gpioRead(gpioPin6)) << "," << "AV-01F=" << to_string(gpioRead(gpioPin7)) << "," << "AV-03P=" << to_string(gpioRead(gpioPin8)) << "," << "camStart=" << to_string(gpioRead(gpioPin9)) << "," << "camStop=" << to_string(gpioRead(gpioPin10)) << "," << "camState1=" << to_string(gpioRead(gpioPin11)) << "," << "camState2=" << to_string(gpioRead(gpioPin12)) << "," << "IGNstart=" << to_string(gpioRead(gpioPin21)) << "," << "IGNbw=" << to_string(gpioRead(gpioPin13)) << "," << "batt1-22=" << to_string(gpioRead(gpioPin14)) << "," << "batt2-22=" << to_string(gpioRead(gpioPin15)) << "," << "batt1-20=" << to_string(gpioRead(gpioPin16)) << "," << "batt2-20=" << to_string(gpioRead(gpioPin17)) << "," << "drogue=" << to_string(gpioRead(gpioPin18)) << "," << "manualAbort=" << to_string(gpioRead(gpioPin19)) << "," << i2cReport(i2cFd) << "," << bufferS << "," << "hello22" << endl;

        outfile << dataS.str() << std::endl; //write data to file

        time_sleep(0.5);
    }

    outfile.close(); // Close the file (not reached in this version)
}

int testState() {
    string input; string pinName;
    int valves[] = { 0,0,0,0,0,0,0,0 };
    int checkFlag = 0;

    //int gpioPin1 = 4; int gpioPin2 = 17; int gpioPin3 = 27; int gpioPin4 = 22; int gpioPin5 = 10; int gpioPin6 = 9; int gpioPin7 = 11; int gpioPin8 = 0; //valves 
    map<string, int> pinName2Num = { //mapping strings to numbers associated with gpioPin values
        {"gpioPin1", 4},
        {"gpioPin2", 17},
        {"gpioPin3", 27},
        {"gpioPin4", 22},
        {"gpioPin5", 10},
        {"gpioPin6", 9},
        {"gpioPin7", 11},
        {"gpioPin8", 0}
    };

    while (1) {
        checkFlag = 0;

        cout << "what is the valve string? (in form '00000000') or 'exit' to exit" << endl;
        cin >> input;

        if (input == "exit") { //exit while loop if exit detected
            break;
        }

        for (int i = 0; i < input.length(); i++) { //store values in an array, goes from 0 to 7 (and input.length()=8)

            if ((input[i] != '0' && input[i] != '1') || input.length() != 8) { // check if values are right, if wrong then break out of surrounding loop
                cout << "wrong input entered, exiting" << endl;
                break;
            }

            pinName = "gpioPin" + to_string(i + 1); //want to store in gpioPin1-8 not 0-7

            //gpioWrite(integer of pin, value to write pin to);
            gpioWrite(pinName2Num[pinName], input[i] - '0'); //C,C++ store chars as ints using their ASCII, so '0'=48, '1'=49, etc. To convert a single char to the int it represents is to subtract the value of '0'.
            cout << "valve changed is: " << pinName << " and its changed to: " << to_string(gpioRead(pinName2Num[pinName])) << endl;
        }

    } // end of while loop
    return 1;
}

void preState() { //call sendData thread and set gpio pulldowns

    int pins[] = { 4,17,27,22,10,9,11,0,6,13,18,23,24,25,8,7,12,16,20,21 };

    for (int i = 0; i < sizeof(pins) / sizeof(pins[0]); i++) {
        gpioSetPullUpDown(pins[i], PI_PUD_DOWN);
    }

    //configures pins 1-10, 18, 20, 21 as write pins and 11-17, 19 as read pins           
    gpioSetMode(gpioPin1, PI_OUTPUT); gpioSetMode(gpioPin2, PI_OUTPUT); gpioSetMode(gpioPin3, PI_OUTPUT); gpioSetMode(gpioPin4, PI_OUTPUT); gpioSetMode(gpioPin5, PI_OUTPUT); gpioSetMode(gpioPin6, PI_OUTPUT); gpioSetMode(gpioPin7, PI_OUTPUT); gpioSetMode(gpioPin8, PI_OUTPUT); gpioSetMode(gpioPin9, PI_OUTPUT); gpioSetMode(gpioPin10, PI_OUTPUT); gpioSetMode(gpioPin18, PI_OUTPUT); gpioSetMode(gpioPin20, PI_OUTPUT); gpioSetMode(gpioPin21, PI_OUTPUT);
    gpioSetMode(gpioPin11, PI_INPUT); gpioSetMode(gpioPin12, PI_INPUT); gpioSetMode(gpioPin13, PI_INPUT); gpioSetMode(gpioPin14, PI_INPUT); gpioSetMode(gpioPin15, PI_INPUT); gpioSetMode(gpioPin16, PI_INPUT); gpioSetMode(gpioPin17, PI_INPUT); gpioSetMode(gpioPin19, PI_INPUT);

    const char* serialPort = "/dev/ttyACM0";
    char* serialPortC = const_cast<char*>(serialPort);

    int serHandle = serOpen(serialPortC, 9600, 0); //for arduino data
    usleep(2 * 1000000);
    if (serHandle < 0) {
        cout << "Failed to open serial device, trying other port" << endl;

        const char* serialPort = "/dev/ttyACM1";
        serialPortC = const_cast<char*>(serialPort);

        serHandle = serOpen(serialPortC, 9600, 0); //for arduino data

        if (serHandle < 0) {
            cout << "Failed to open serial device, both ports failed" << endl;
        }
    }

    int i2cFd = -1;
    const char* bus = "/dev/i2c-1"; //open i2c bus
    if ((i2cFd = open(bus, O_RDWR)) < 0) {
        cout << "erri2cFail" << endl;
    }

    //thread thread2(sendData);
    thread thread2(sendData, serHandle, i2cFd);
    thread2.detach();

    string input;
    cout << "test program?: (type 'yes' if yes, type anything else to go to state0)" << endl;
    cin >> input;

    if (input == "yes") {
        testState();
    }
}

void mState0(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState0: idle
    cout << "entering mState0" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10); //writes values that need to be written, then read (and to_string) all values

    moveState(state, v9, v10); //asks GS for response, can leave as is or can add failure check since it returns "1" if successful
    cout << "exiting mState0" << endl;
}

void mStateGeneric(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    cout << "entering mState" << state << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);


    if (gpioRead(gpioPin13) == 0 && (state == 6 || state == 7 || state == 8 || state == 9)) {
        cout << "entering pauseState because ignitor wire is burnt too early" << endl;
        pauseState(v9, v10);
    }

    moveState(state, v9, v10);
    cout << "exiting mState" << state << endl;
}

void mState10(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState10: go for test, start ignitor
    cout << "entering mState10" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    string input;

    while (1) {
        time_sleep(5);
        if (gpioRead(gpioPin13) == 0) {
            break;
        }

        cout << "wire hasn't burned, carry on anyways? (yes for yes, anything else to enter pauseState)" << endl;
        cin >> input;

        if (input == "yes") {
            cout << "burning wire via program" << endl;
            time_sleep(1);
            break;
        }
        else {
            pauseState(v9, v10);
        }
    }

    cout << "exiting mState10" << endl;
    void mState11(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState11(11, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0);
}

void mState11(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState11: waiting for ignitor
    cout << "entering mState11" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    time_sleep(5);

    cout << "exiting mState11" << endl;
    void mState12(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState12(12, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0);
}

void mState12(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState12: open engine fuel valve
    cout << "entering mState12" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    time_sleep(0.85);

    cout << "exiting mState12" << endl;
    void mState13(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState13(13, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0);
}

void mState13(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState13: open engine lox valve
    cout << "entering mState13" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    cout << "exiting mState13" << endl;
    void mState14(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState14(14, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0);
}

void mState14(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState14: testing
    cout << "entering mState14" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    time_sleep(15);

    cout << "exiting mState14" << endl;
    void mState15(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState15(15, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0);
}

void mState15(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState15: stop test, close all valves
    cout << "entering mState15" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    time_sleep(1);

    cout << "exiting mState15" << endl;
    void mState16(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState16(16, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0);
}

void mState16(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState16: vent tanks
    cout << "entering mState16" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    int check = 0;
    string input = "";

    while (check == 0) {
        cout << "move? (type 'yes' if yes)" << endl;
        cin >> input;

        if (input == "yes") {
            check = 1;
        }
    }

    cout << "exiting mState16" << endl;
    void mState17(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10); //prototype
    mState17(17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}

void mState17(int state, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    //mState17: test complete
    cout << "entering mState17" << endl;
    gpioSet(v1, v2, v3, v4, v5, v6, v7, v8, v9, v10);

    string input;
    cout << "test program?: (type 'yes' if yes, type anything else to go to state0)" << endl;
    cin >> input;

    if (input == "yes") {
        testState();
    }

    cout << "exiting mState17" << endl;
}

//cd /home/pi/Desktop/piMainTestF/SFTfiles
//g++ -o programSFTE programSFT.cpp functionsSFT.cpp -lpigpio -lrt -lpthread
//sudo ./programSFTE 



