#include <stdio.h>
#include <time.h>
#include <unistd.h>

int main() {
    // Declare variables
    time_t current_time;
    struct tm *timeinfo;
    char time_string[80]; // Buffer to store the formatted time string
    
    while (1) {
    // Get the current system time
    current_time = time(NULL);

    // Check if the time retrieval was successful
    if (current_time == ((time_t)-1)) {
        // Error handling if time retrieval failed
        perror("Error getting time");
        return 1;
    }

    // Convert time_t to struct tm (local time)
    timeinfo = localtime(&current_time);

    // Format the time as a string
    strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", timeinfo);

    // Print the formatted time string

    printf("Current system time: %s\n", time_string);
	usleep(2*1000000);
	}
    
    return 0;
}

// cd /home/pi/Desktop/piMainTestF/CFTfiles
// g++ -o systemTimeE systemTime.cpp
