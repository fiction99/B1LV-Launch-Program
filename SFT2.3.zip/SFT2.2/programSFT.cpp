#include <iostream>
#include <pigpio.h>
#include <cstring>
#include <thread>
#include <functional>
#include <chrono>
#include <string>
#include <unistd.h>
#include <fstream>

#include "functionsSFT.h"

using namespace std;


//defines state# + gpioPin1-10: AV-01P, AV-02P, AV-01N, AV-02N, AV-01O, AV-02O, AV-01F, AV-03P, camStart, camStop 
void mStateBegin() {

    cout << "entering mStateBegin" << endl;
    int check = 0;
    string input = "";

    preState();
    while (check == 0) {
        pid_t processName = getpid();
        cout << "PID is " << processName << endl; // use "kill -2 <PID>" to kill program in terminal

        mState0(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //state0
        mStateGeneric(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //state1
        mStateGeneric(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //state2
        mStateGeneric(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //state3
        mStateGeneric(4, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0); //state4
        mStateGeneric(5, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0); //state5
        mStateGeneric(6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //state6
        mStateGeneric(7, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); //state7
        mStateGeneric(8, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0); //state8
        mStateGeneric(9, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0); //state9
        mState10(10, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0); //state10

        cout << "end program?: (type 'yes' if yes, type anything else to go to state0)" << endl;
        cin >> input;

        if (input == "yes") {
            check = 1;
        }

    }
        
    gpioTerminate(); //close pigpio
    cout << "exiting mStateBegin" << endl;
}


int main() {
    cout << "program begin" << endl;
	//gpioInitialise();
    if (gpioInitialise() < 0) {
        cerr << "Failed to initialize pigpio" << endl;
        return 1;
    }

    mStateBegin(); //C strings are represented as "char* test" or "char test[]" and must be null terminated, pigpio accepts C string inputs in its functions

/*
    while (1) { //infinite loop to keep threads running forever
        time_sleep(1);
    }
*/
    cout << "program ending" << endl;
    gpioTerminate(); //close pigpio
    return 0;

}




